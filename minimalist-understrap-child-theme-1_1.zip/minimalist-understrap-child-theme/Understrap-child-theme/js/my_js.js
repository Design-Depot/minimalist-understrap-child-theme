(function($) {

    console.log('jQuery with dollar sign is working');

})( jQuery );